
async function loadJSON(path){
  const res = await fetch(path);
  if(!res.ok) throw new Error(`Failed to load ${path}`);
  return await res.json();
}
async function loadText(path){
  const res = await fetch(path);
  if(!res.ok) throw new Error(`Failed to load ${path}`);
  return await res.text();
}
function parseFrontmatter(raw){
  const match = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if(!match) return {data:{}, body: raw};
  const yaml = match[1];
  const body = match[2] || "";
  const data = {};
  const lines = yaml.split('\n');
  let currentKey = null;
  let multiline = false;
  for(const line of lines){
    if(multiline){
      if(/^\S/.test(line)){
        multiline = false;
      } else {
        data[currentKey] += "\n" + line.replace(/^  /,'');
        continue;
      }
    }
    const m = line.match(/^([A-Za-z0-9_]+):\s*(.*)$/);
    if(m){
      let [,key,val] = m;
      currentKey = key;
      if(val === '|'){
        data[key] = "";
        multiline = true;
      } else {
        val = val.replace(/^"(.*)"$/,'$1');
        if(val === 'true') val = true;
        else if(val === 'false') val = false;
        data[key] = val;
      }
    }
  }
  return {data, body};
}
async function loadCollection(prefix, count){
  const items = [];
  for(let i=1;i<=count;i++){
    try{
      const raw = await loadText(`content/${prefix}/${prefix.slice(0,-1)}-${i}.md`);
      const parsed = parseFrontmatter(raw);
      items.push(parsed.data);
    }catch(e){}
  }
  return items;
}
function formatCurrency(num){
  return new Intl.NumberFormat('ru-RU').format(Math.round(num)) + ' BYN';
}
function qs(sel){ return document.querySelector(sel); }

async function init(){
  const site = await loadJSON('content/site.json');
  document.title = site.seo?.title || site.brand;
  qs('[data-brand]').textContent = site.brand;
  qs('[data-hero-title]').textContent = site.heroTitle;
  qs('[data-hero-sub]').textContent = site.heroSubtitle;
  qs('[data-phone-display]').textContent = site.phoneDisplay;
  qs('[data-phone-link]').href = `tel:${site.phoneLink}`;
  qs('[data-price-from]').textContent = site.priceFrom;
  qs('[data-city]').textContent = site.city;
  qs('[data-wa]').href = site.whatsappLink;
  qs('[data-tg]').href = site.telegramLink;
  qs('[data-ig]').href = site.instagramLink;

  const featuresWrap = qs('#features');
  featuresWrap.innerHTML = (site.features || []).map(item => `<div class="feature">${item}</div>`).join('');
  const servicesWrap = qs('#services');
  servicesWrap.innerHTML = (site.services || []).map(item => `<article class="card"><h3>${item.title}</h3><p class="section-sub">${item.text}</p></article>`).join('');

  const promo = site.promo || {};
  const promoEl = qs('#promo');
  if(promo.enabled){
    promoEl.classList.add('active');
    promoEl.innerHTML = `<span class="badge">${promo.badge || 'Акция'}</span><h3 style="font-size:30px;margin:14px 0 8px">${promo.title || ''}</h3><p style="color:#d4d7df;line-height:1.6;margin:0">${promo.text || ''}</p>`;
  }

  const works = await loadCollection('works', 24);
  qs('#works').innerHTML = works.map(item => `
    <article class="work">
      <img src="${item.cover || '/assets/img/work-1.svg'}" alt="${item.title || ''}">
      <div class="work-content">
        <div class="small">${item.date || ''}</div>
        <h3>${item.title || ''}</h3>
        <p class="section-sub">${item.summary || ''}</p>
        <strong>${item.price || ''}</strong>
      </div>
    </article>`).join('');

  const posts = await loadCollection('posts', 24);
  qs('#posts').innerHTML = posts.map(item => `
    <article class="post">
      <img src="${item.cover || '/assets/img/post-1.svg'}" alt="${item.title || ''}">
      <div class="post-content">
        <div class="small">${item.date || ''}</div>
        <h3>${item.title || ''}</h3>
        <p class="section-sub">${item.excerpt || ''}</p>
      </div>
    </article>`).join('');

  const typeSel = qs('#calc-type');
  const stepsInput = qs('#calc-steps');
  const materialSel = qs('#calc-material');
  const finishSel = qs('#calc-finish');
  const complexSel = qs('#calc-complexity');
  const calcOut = qs('#calc-out');

  function recalc(){
    const steps = parseInt(stepsInput.value || '15', 10);
    const materialMap = site.materials || {pine:1,birch:1.15,ash:1.35,oak:1.55,metal_wood:1.7};
    const materialFactor = materialMap[materialSel.value] || 1;
    const finishFactor = parseFloat(finishSel.value || '1');
    const typeFactor = parseFloat(typeSel.value || '1');
    const complexFactor = parseFloat(complexSel.value || '1');
    const total = (site.baseProjectPrice + steps * site.pricePerStep) * materialFactor * finishFactor * typeFactor * complexFactor;
    calcOut.innerHTML = `<strong style="font-size:32px;display:block;margin-bottom:6px">${formatCurrency(total)}</strong><div class="small" style="color:#cbd5e1">Предварительный расчёт. Точная цена зависит от замера, конструкции, ограждения и отделки.</div>`;
  }
  [typeSel,stepsInput,materialSel,finishSel,complexSel].forEach(el => el.addEventListener('input', recalc));
  recalc();
}
init().catch(err => {
  console.error(err);
  const el = document.querySelector('#app-error');
  if(el) el.textContent = 'Не удалось загрузить контент. Для локального просмотра лучше открыть сайт через хостинг или локальный сервер.';
});
