title: "Лестница на бетон с ясенем"
date: "2026-04-12"
price: "от 6 800 BYN"
cover: "/assets/img/work-1.svg"
summary: "Поворотная лестница с отделкой из ясеня, чёрными трубками и поручнем из берёзы."
featured: true
